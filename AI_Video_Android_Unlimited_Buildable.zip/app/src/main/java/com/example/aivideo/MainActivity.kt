package com.example.aivideo

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Bg = Color(0xFF070B16)
private val Panel = Color(0xFF111A2C)
private val Panel2 = Color(0xFF17233A)
private val Muted = Color(0xFF9BA9C5)
private val Cyan = Color(0xFF18C8F4)
private val Purple = Color(0xFF7957FF)
private val Pink = Color(0xFFEF4ACB)

data class VideoProject(
    val id: String,
    val prompt: String,
    val style: String,
    val ratio: String,
    val createdAt: Long,
    val status: String = "Черновик",
    val videoUri: String = "",
    val sourceImageUri: String = ""
)

class ProjectStore(context: Context) {
    private val prefs = context.getSharedPreferences("ai_video_projects", Context.MODE_PRIVATE)
    fun load(): List<VideoProject> {
        return try {
            val array = JSONArray(prefs.getString("projects", "[]"))
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                VideoProject(
                    id = o.optString("id", UUID.randomUUID().toString()),
                    prompt = o.optString("prompt"),
                    style = o.optString("style", "Реализм"),
                    ratio = o.optString("ratio", "9:16"),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    status = o.optString("status", "Черновик"),
                    videoUri = o.optString("videoUri"),
                    sourceImageUri = o.optString("sourceImageUri")
                )
            }.sortedByDescending { it.createdAt }
        } catch (_: Exception) { emptyList() }
    }
    fun save(projects: List<VideoProject>) {
        val array = JSONArray()
        projects.forEach { p ->
            array.put(JSONObject().apply {
                put("id", p.id); put("prompt", p.prompt); put("style", p.style)
                put("ratio", p.ratio); put("createdAt", p.createdAt); put("status", p.status)
                put("videoUri", p.videoUri); put("sourceImageUri", p.sourceImageUri)
            })
        }
        // No app-imposed project-count limit. Actual storage is limited by available device space.
        prefs.edit().putString("projects", array.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ProjectStore(applicationContext)
        setContent { AIVideoApp(store) }
    }
}

@Composable
fun AIVideoApp(store: ProjectStore) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var projects by remember { mutableStateOf(store.load()) }
    var prompt by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Реализм") }
    var ratio by remember { mutableStateOf("9:16") }
    var sourceImageUri by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var selectedProject by remember { mutableStateOf<VideoProject?>(null) }

    fun updateProjects(newProjects: List<VideoProject>) {
        projects = newProjects.sortedByDescending { it.createdAt }
        store.save(projects)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple, onBackground = Color.White,
        onSurface = Color.White, secondary = Cyan
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B1120), contentColor = Muted) {
                    NavigationBarItem(selectedTab == 0, { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главная") })
                    NavigationBarItem(selectedTab == 1, { selectedTab = 1 }, icon = { Icon(Icons.Default.Movie, null) }, label = { Text("Мои проекты") })
                    NavigationBarItem(selectedTab == 2, { selectedTab = 2 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Профиль") })
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(
                    Modifier.padding(padding), prompt, { prompt = it }, style, { style = it },
                    ratio, { ratio = it }, sourceImageUri, { sourceImageUri = it },
                    onCreateProject = {
                        if (prompt.isBlank()) message = "Сначала опиши идею будущего видео."
                        else {
                            val p = VideoProject(
                                id = UUID.randomUUID().toString(), prompt = prompt.trim(),
                                style = style, ratio = ratio, createdAt = System.currentTimeMillis(),
                                status = "Ожидает подключения ИИ", sourceImageUri = sourceImageUri
                            )
                            updateProjects(listOf(p) + projects)
                            message = "Проект сохранён в истории. Чтобы получить настоящее видео, подключи ИИ-генератор в серверной части."
                            selectedTab = 1
                        }
                    },
                    onPickExample = { prompt = it }
                )
                1 -> LibraryScreen(
                    Modifier.padding(padding), projects,
                    onOpen = { selectedProject = it },
                    onDelete = { p -> updateProjects(projects.filterNot { it.id == p.id }) },
                    onExport = { p -> message = "Экспорт видео будет доступен после подключения ИИ-генератора. Проект и его история сохранены локально." }
                )
                else -> ProfileScreen(Modifier.padding(padding), projects.size)
            }
            message?.let { msg ->
                AlertDialog(
                    onDismissRequest = { message = null }, containerColor = Panel2,
                    title = { Text("AI Video") }, text = { Text(msg) },
                    confirmButton = { TextButton(onClick = { message = null }) { Text("Понятно") } }
                )
            }
            selectedProject?.let { p ->
                AlertDialog(
                    onDismissRequest = { selectedProject = null },
                    containerColor = Panel2,
                    title = { Text("Проект") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(p.prompt)
                            Text("Стиль: ${p.style} • Формат: ${p.ratio}", color = Muted)
                            Text("Создан: ${formatDate(p.createdAt)}", color = Muted, fontSize = 12.sp)
                            Text("Статус: ${p.status}", color = Cyan, fontSize = 12.sp)
                        }
                    },
                    confirmButton = { TextButton(onClick = { prompt = p.prompt; style = p.style; ratio = p.ratio; selectedProject = null; selectedTab = 0 }) { Text("Редактировать") } },
                    dismissButton = { TextButton(onClick = { selectedProject = null }) { Text("Закрыть") } }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier, prompt: String, onPrompt: (String) -> Unit,
    style: String, onStyle: (String) -> Unit, ratio: String, onRatio: (String) -> Unit,
    sourceImageUri: String, onImage: (String) -> Unit,
    onCreateProject: () -> Unit, onPickExample: (String) -> Unit
) {
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        onImage(uri?.toString().orEmpty())
    }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Cyan, Purple, Pink)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                    Column {
                        Text("AI Video", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Твоя идея — твоё видео", fontSize = 11.sp, color = Muted)
                    }
                }
                Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFFFC857), modifier = Modifier.size(26.dp))
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Создай своё видео", fontSize = 30.sp, lineHeight = 35.sp, fontWeight = FontWeight.ExtraBold)
                Text("с ИИ в один клик", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold,
                    color = Cyan)
                Text("Без лимита на количество проектов. История сохраняется на устройстве.", color = Muted, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionTitle("Опиши свою идею", "${prompt.length}/500")
                Box(Modifier.fillMaxWidth().height(132.dp).background(Panel, RoundedCornerShape(18.dp)).padding(15.dp)) {
                    if (prompt.isEmpty()) Text("Например: кот-космонавт летит над Землёй…", color = Muted, fontSize = 14.sp)
                    BasicTextField(
                        value = prompt, onValueChange = { if (it.length <= 500) onPrompt(it) },
                        modifier = Modifier.fillMaxSize(), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp, lineHeight = 21.sp)
                    )
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionTitle("Выбери стиль", "4 стиля")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("Реализм", "Аниме", "3D", "Кино").forEach { s ->
                        val active = style == s
                        Box(Modifier.weight(1f).background(if (active) Brush.horizontalGradient(listOf(Purple, Pink)) else Brush.linearGradient(listOf(Panel2, Panel2)), RoundedCornerShape(22.dp)).clickable { onStyle(s) }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
                            Text(s, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                        }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionTitle("Формат видео", "Под платформу")
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    listOf("9:16", "16:9", "1:1").forEach { r ->
                        val active = ratio == r
                        Row(Modifier.weight(1f).background(if (active) Color(0xFF29224D) else Panel, RoundedCornerShape(13.dp)).clickable { onRatio(r) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            Icon(if (r == "9:16") Icons.Default.Smartphone else if (r == "16:9") Icons.Default.Laptop else Icons.Default.CropSquare, null, tint = if (active) Cyan else Muted, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp)); Text(r, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp)) {
                Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp))
                Text(if (sourceImageUri.isBlank()) "Добавить фотографию" else "Фотография выбрана ✓")
            }
        }
        item {
            Button(onClick = onCreateProject, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(8.dp))
                Text("Создать проект", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        item { Text("Быстрые идеи", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        items(listOf(
            Triple("🐱", "Кот в космосе", "Реалистичный кот-космонавт смотрит на Землю из космоса, кинематографический свет"),
            Triple("🏞️", "Фэнтези-мир", "Величественный замок в горах на закате, магический туман, эпическое кино"),
            Triple("🐼", "Панда в лесу", "Милая панда гуляет по бамбуковому лесу, мягкий солнечный свет"),
            Triple("🌃", "Город будущего", "Футуристический город с неоновыми небоскрёбами ночью, пролетающая камера")
        )) { example ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { onPickExample(example.third) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).background(Brush.linearGradient(listOf(Color(0xFF1A4566), Color(0xFF623C8C))), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text(example.first, fontSize = 27.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(example.second, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Нажми, чтобы заполнить описание", color = Muted, fontSize = 11.sp, maxLines = 1)
                }
                Icon(Icons.Default.AddCircle, null, tint = Cyan)
            }
        }
        item { Text("Проекты хранятся локально. Реальная генерация видео подключается отдельно; число проектов приложением не ограничено.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp) }
    }
}

@Composable
fun SectionTitle(title: String, action: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f)); Text(action, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun LibraryScreen(
    modifier: Modifier, projects: List<VideoProject>,
    onOpen: (VideoProject) -> Unit, onDelete: (VideoProject) -> Unit, onExport: (VideoProject) -> Unit
) {
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 20.dp)) {
        Text("Мои проекты", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        Text("${projects.size} проектов • без искусственного лимита", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        if (projects.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Default.VideoLibrary, null, tint = Purple, modifier = Modifier.size(60.dp))
                    Text("Пока здесь пусто", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Создай проект на главной странице — он останется в истории после перезапуска приложения.", color = Muted, textAlign = TextAlign.Center)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(projects, key = { it.id }) { p ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(17.dp)).clickable { onOpen(p) }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(60.dp).background(Brush.linearGradient(listOf(Purple, Cyan)), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                            Icon(if (p.videoUri.isNotBlank()) Icons.Default.PlayCircle else Icons.Default.MovieCreation, null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(p.prompt, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 2)
                            Text("${p.style} • ${p.ratio}", color = Muted, fontSize = 11.sp)
                            Text("${p.status} • ${formatDate(p.createdAt)}", color = Cyan, fontSize = 10.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(onClick = { onExport(p) }) { Icon(Icons.Default.Download, "Экспорт", tint = Cyan) }
                            IconButton(onClick = { onDelete(p) }) { Icon(Icons.Default.DeleteOutline, "Удалить", tint = Muted) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(modifier: Modifier, projectCount: Int) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Профиль", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).background(Brush.linearGradient(listOf(Cyan, Purple, Pink)), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Создатель видео", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("Локальный профиль • демо-режим", color = Muted, fontSize = 12.sp)
            }
        }
        listOf("Проектов в истории: $projectCount", "Количество проектов не ограничено приложением", "История хранится на этом устройстве", "AI Video 1.1.0").forEach {
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = Cyan)
                Spacer(Modifier.width(12.dp)); Text(it, modifier = Modifier.weight(1f), fontSize = 13.sp)
            }
        }
        Text("Примечание: сохранение истории не равно хранению самих видеофайлов. Когда будет подключён генератор, готовые ролики можно будет скачивать в память телефона.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

fun formatDate(time: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(time))
